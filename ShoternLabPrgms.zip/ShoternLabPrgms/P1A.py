total_outcomes = 6

favorable_outcomes = 1

probability = favorable_outcomes/total_outcomes

print(f"The Probability of getting 4 on a dice of 6 is {probability:.2f} or {round(probability, 2)}")